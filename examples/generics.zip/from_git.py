def func(self):
	"""
	asdf
	"""
	from app import func
	return func(self)
