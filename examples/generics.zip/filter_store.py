def func(self):
	k = self.GET['k']
	v = self.GET['v']
	self.info(self.rid, "filter store for k '%s', v '%s'" % (k, v))
	l = [row.data for row in self.datastore.all()]
	self.info(self.rid, str(l))
	return l, len(self.datastore.all())
