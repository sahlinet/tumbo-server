def func(self):
	pip = self.foreigns.pip_install(self)
	yum = self.foreigns.yum_install(self)
	return pip, yum