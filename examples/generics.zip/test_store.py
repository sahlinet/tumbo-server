def func(self):
	from fastapp.plugins.datastore import DataObject
	
	data = {"name": "Rolf"}
	
	obj_dict=DataObject(data=data)
	self.datastore.write_obj(obj_dict)
	
	print self.datastore.all()
	#return str(dir(self.datastore))
	return len(self.datastore.all())