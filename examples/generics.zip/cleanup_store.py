def func(self):
	results = self.datastore.all()
	count = len(results)
	for row in self.datastore.all():
		self.datastore.session.delete(row)
	self.datastore.session.commit()
	return count
	