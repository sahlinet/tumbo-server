def func(self):
    return "bar"
