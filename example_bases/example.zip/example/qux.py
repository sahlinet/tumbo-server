def func(self):
	from app import func
	return func(self)