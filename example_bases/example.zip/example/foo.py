def func(self):
    pass